package modelo;

/**
 * Clase abstracta que representa una onda en la señal ECG
 */

public abstract class Onda extends Componente {
    private static final long serialVersionUID = 1L;
    
    public Onda() {}
    
    public Onda(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}