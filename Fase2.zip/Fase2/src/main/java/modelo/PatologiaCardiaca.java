package modelo;

/**
 * Diagnóstico relacionado con enfermedades estructurales o funcionales del corazón
 */
public abstract class PatologiaCardiaca extends Diagnostico {
    private static final long serialVersionUID = 1L;
    
    public PatologiaCardiaca() {}
    
    public PatologiaCardiaca(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}