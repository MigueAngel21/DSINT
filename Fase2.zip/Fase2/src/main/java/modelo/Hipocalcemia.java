package modelo;

/**
 * Diagnóstico de Hipocalcemia (nivel bajo de calcio en sangre).
 *
 * Criterio:
 * - IntervaloQT prolongado (> 440 ms).
 */
public class Hipocalcemia extends AnomaliaElectrica {
    private static final long serialVersionUID = 1L;
    
    public Hipocalcemia() {}
    
    public Hipocalcemia(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}