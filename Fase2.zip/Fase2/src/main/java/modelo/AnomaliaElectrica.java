package modelo;

/**
 * Diagnóstico relacionado con alteraciones electrolíticas
 */
public abstract class AnomaliaElectrica extends Diagnostico {
    private static final long serialVersionUID = 1L;
    
    public AnomaliaElectrica() {}
    
    public AnomaliaElectrica(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}
