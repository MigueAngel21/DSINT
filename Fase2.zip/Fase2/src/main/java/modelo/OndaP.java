package modelo;

/**
 * Representa la despolarización auricular
 */
public class OndaP extends Onda {
    private static final long serialVersionUID = 1L;
    
    public OndaP() {}
    
    public OndaP(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}