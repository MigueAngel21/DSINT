package modelo;

/**
 * Necrosis del músculo cardíaco debido a isquemia prolongada
 * Criterios: Elevación del segmento ST.
 */
public class InfartoAgudoMiocardio extends PatologiaCardiaca {
    private static final long serialVersionUID = 1L;
    
    public InfartoAgudoMiocardio() {}
    
    public InfartoAgudoMiocardio(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}