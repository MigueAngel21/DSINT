package modelo;

/**
 * Nivel bajo de potasio en sangre
 * Criterios: Ondas T aplanadas o invertidas
 */
public class Hipopotasemia extends AnomaliaElectrica {
    private static final long serialVersionUID = 1L;
    
    public Hipopotasemia() {}
    
    public Hipopotasemia(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}