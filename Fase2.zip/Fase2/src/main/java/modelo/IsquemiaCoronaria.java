package modelo;

/**
 * Reducción del flujo sanguíneo al músculo cardíaco
 * Criterios: Depresión del segmento ST e inversión de onda T
 */
public class IsquemiaCoronaria extends PatologiaCardiaca {
    private static final long serialVersionUID = 1L;
    
    public IsquemiaCoronaria() {}
    
    public IsquemiaCoronaria(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}