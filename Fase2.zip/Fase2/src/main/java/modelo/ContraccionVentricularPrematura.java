package modelo;

/**
 * Diagnóstico de Contracción Ventricular Prematura (CVP).
 *
 * Criterios:
 * - ComplejoQRS ancho (> 100 ms).
 * - Ausencia de OndaP en el ciclo.
 * - IntervaloRR prematuro (seguido de pausa compensatoria).
 */

public class ContraccionVentricularPrematura extends Arritmia {
    private static final long serialVersionUID = 1L;
    
    public ContraccionVentricularPrematura() {}
    
    public ContraccionVentricularPrematura(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}