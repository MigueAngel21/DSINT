package sistema;

import modelo.*;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import java.io.*;
import java.util.*;

/**
 * Sistema principal que procesa ficheros ECG usando Drools
 */
public class SistemaECG {
    
    private static String dirEnt = "./entrada";
    private static String dirSal = "./salida";
    
    public static void main(String[] args) {
        if (args.length >= 1) {
            dirEnt = args[0];
        }
        if (args.length >= 2) {
            dirSal = args[1];
        }
        
        System.out.println("===========================================");
        System.out.println("  SISTEMA DE ANÁLISIS DE ECG - Fase 2");
        System.out.println("===========================================");
        System.out.println("Directorio entrada: " + dirEnt);
        System.out.println("Directorio salida: " + dirSal);
        System.out.println();
        
        File dirSalida = new File(dirSal);
        if (!dirSalida.exists()) {
            dirSalida.mkdirs();
        }
        
        File dirEntrada = new File(dirEnt);
        File[] ficheros = dirEntrada.listFiles((dir, name) -> name.endsWith(".ecg"));
        
        if (ficheros == null || ficheros.length == 0) {
            System.out.println("No se encontraron ficheros .ecg en " + dirEnt);
            return;
        }
        
        StringBuilder todoSalida = new StringBuilder();
        todoSalida.append("RESUMEN DE ANÁLISIS DE TODOS LOS FICHEROS\n");
        todoSalida.append("===========================================\n\n");
        
        for (File fichero : ficheros) {
            System.out.println("Procesando: " + fichero.getName());
            String resultado = procesarFicheroECG(fichero);
            
            String nombreSalida = fichero.getName().replace(".ecg", ".salida.txt");
            guardarResultado(dirSal + File.separator + nombreSalida, resultado);
            
            todoSalida.append("Fichero: ").append(fichero.getName()).append("\n");
            todoSalida.append(resultado).append("\n");
            todoSalida.append("-------------------------------------------\n\n");
        }
        
        String rutaTodoSalida = dirSal + File.separator + "todo.salida.txt";
        guardarResultado(rutaTodoSalida, todoSalida.toString());
        
        System.out.println("\n===========================================");
        System.out.println("CONTENIDO DE todo.salida.txt:");
        System.out.println("===========================================\n");
        System.out.println(todoSalida.toString());
    }
    
    private static String procesarFicheroECG(File fichero) {
        StringBuilder resultado = new StringBuilder();
        
        try {
            List<Onda> ondas = ECGParser.parsearFichero(fichero.getAbsolutePath());
            int numCiclos = ECGParser.calcularNumeroCiclos(ondas);
            
            KieServices ks = KieServices.Factory.get();
            KieContainer kContainer = ks.getKieClasspathContainer();
            
            if (kContainer == null) {
                return "ERROR: No se pudo cargar el contenedor de Drools. Verificar kmodule.xml\n";
            }
            
            KieSession kSession = kContainer.newKieSession("ksession-ecg");
            
            if (kSession == null) {
                return "ERROR: No se pudo crear la sesión 'ksession-ecg'. Verificar kmodule.xml y reglas.\n";
            }
            
            RegistroECG registro = new RegistroECG(fichero.getName());
            kSession.insert(registro);
            
            for (Onda onda : ondas) {
                kSession.insert(onda);
            }
            
            for (int i = 1; i <= numCiclos; i++) {
                kSession.insert(new Ciclo(i));
            }
            
            kSession.getAgenda().getAgendaGroup("calculo-elementos").setFocus();
            kSession.fireAllRules();
            
            kSession.getAgenda().getAgendaGroup("calculo-metricas").setFocus();
            kSession.fireAllRules();
            
            kSession.getAgenda().getAgendaGroup("diagnostico-basico").setFocus();
            kSession.fireAllRules();
            
            kSession.getAgenda().getAgendaGroup("diagnostico-avanzado").setFocus();
            kSession.fireAllRules();
            
            kSession.getAgenda().getAgendaGroup("diagnostico").setFocus();
            kSession.fireAllRules();
            
            System.out.println("--- Reporte de elementos calculados ---");
            kSession.getAgenda().getAgendaGroup("reporte").setFocus();
            kSession.fireAllRules();
            System.out.println("---------------------------------------");
            
            resultado.append("Registro ECG: ").append(fichero.getName()).append("\n");
            resultado.append("Total de ciclos: ").append(registro.getTotalCiclos()).append("\n");
            resultado.append("Frecuencia cardíaca: ")
                    .append(registro.getFrecuenciaCardiaca())
                    .append(" ppm\n\n");
            
            Collection<Diagnostico> diagnosticos = new ArrayList<>();
            for (Object obj : kSession.getObjects()) {
                if (obj instanceof Diagnostico) {
                    diagnosticos.add((Diagnostico) obj);
                }
            }
            
            if (!diagnosticos.isEmpty()) {
                resultado.append("DIAGNÓSTICOS:\n");
                for (Diagnostico dx : diagnosticos) {
                    resultado.append("  - ").append(dx.toString()).append("\n");
                }
            } else {
                resultado.append("DIAGNÓSTICO: Normal\n");
            }
            
            kSession.dispose();
            
        } catch (IOException e) {
            resultado.append("ERROR al leer fichero: ").append(e.getMessage()).append("\n");
            e.printStackTrace();
        } catch (NullPointerException e) {
            resultado.append("ERROR: Problema de configuración de Drools.\n");
            resultado.append("Verificar:\n");
            resultado.append("  1. kmodule.xml existe en src/main/resources/META-INF/\n");
            resultado.append("  2. ecg_rules.drl existe en src/main/resources/rules/\n");
            resultado.append("  3. El package en .drl coincide con el nombre de la carpeta\n");
            e.printStackTrace();
        } catch (Exception e) {
            resultado.append("ERROR al procesar fichero: ").append(e.getMessage()).append("\n");
            e.printStackTrace();
        }
        
        return resultado.toString();
    }
    
    private static void guardarResultado(String rutaArchivo, String contenido) {
        try (PrintWriter pw = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream(rutaArchivo), "UTF-8"))) {
            pw.print(contenido);
        } catch (IOException e) {
            System.err.println("Error al guardar " + rutaArchivo + ": " + e.getMessage());
        }
    }
}