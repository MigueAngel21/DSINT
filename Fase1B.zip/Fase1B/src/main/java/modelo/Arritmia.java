package modelo;

/**
 * Clase abstracta que representa las patologías cardíacas producidas por una
 * frecuencia cardíaca anormal.
 */

public abstract class Arritmia extends Diagnostico {
    private static final long serialVersionUID = 1L;
    
    public Arritmia() {}
    
    public Arritmia(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}
