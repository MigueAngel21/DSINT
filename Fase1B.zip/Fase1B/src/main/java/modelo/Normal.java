package modelo;

public class Normal extends Diagnostico {
    private static final long serialVersionUID = 1L;
    
    public Normal() {}
    
    public Normal(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}