package modelo;

public class Bradicardia extends Arritmia {
    private static final long serialVersionUID = 1L;
    
    public Bradicardia() {}
    
    public Bradicardia(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}