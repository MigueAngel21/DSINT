package modelo;

/**
 * Clase abstracta para componentes formados por múltiples ondas
 */

public abstract class ElementoCompuesto extends Componente {
    private static final long serialVersionUID = 1L;
    
    public ElementoCompuesto() {}
    
    public ElementoCompuesto(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}
