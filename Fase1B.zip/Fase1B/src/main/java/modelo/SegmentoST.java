package modelo;

public class SegmentoST extends Segmento {
    private static final long serialVersionUID = 1L;
    
    public SegmentoST() {}
    
    public SegmentoST(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}