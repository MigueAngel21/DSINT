package modelo;

public class OndaT extends Onda {
    private static final long serialVersionUID = 1L;
    
    public OndaT() {}
    
    public OndaT(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}