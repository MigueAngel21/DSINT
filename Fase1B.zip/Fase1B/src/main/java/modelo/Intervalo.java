package modelo;

/**
 * Clase abstracta que representa un intervalo dentro de un ciclo en un ECG. 
 */
public abstract class Intervalo extends ElementoCompuesto {
    private static final long serialVersionUID = 1L;
    
    public Intervalo() {}
    
    public Intervalo(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}