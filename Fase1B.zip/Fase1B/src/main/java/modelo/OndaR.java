package modelo;

public class OndaR extends Onda {
    private static final long serialVersionUID = 1L;
    
    public OndaR() {}
    
    public OndaR(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}