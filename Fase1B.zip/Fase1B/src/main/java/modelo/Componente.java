package modelo;

import java.io.Serializable;

/**
 * Clase abstracta que representa cualquier componente identificable en la señal ECG
 */
public abstract class Componente implements Serializable {
    private static final long serialVersionUID = 1L;
    
    protected int tiempoInicio;
    protected int tiempoFin;
    protected int duracion;
    protected double amplitudMaxima;
    protected int ciclo;
    
    public Componente() {}
    
    public Componente(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        this.tiempoInicio = tiempoInicio;
        this.tiempoFin = tiempoFin;
        this.duracion = tiempoFin - tiempoInicio;
        this.amplitudMaxima = amplitudMaxima;
        this.ciclo = ciclo;
    }
    
    // Getters y Setters
    public int getTiempoInicio() { return tiempoInicio; }
    public void setTiempoInicio(int tiempoInicio) { this.tiempoInicio = tiempoInicio; }
    
    public int getTiempoFin() { return tiempoFin; }
    public void setTiempoFin(int tiempoFin) { this.tiempoFin = tiempoFin; }
    
    public int getDuracion() { return duracion; }
    public void setDuracion(int duracion) { this.duracion = duracion; }
    
    public double getAmplitudMaxima() { return amplitudMaxima; }
    public void setAmplitudMaxima(double amplitudMaxima) { this.amplitudMaxima = amplitudMaxima; }
    
    public int getCiclo() { return ciclo; }
    public void setCiclo(int ciclo) { this.ciclo = ciclo; }
    
    public String toString() {
        return this.getClass().getSimpleName() + 
               "(inicio=" + tiempoInicio + 
               ", fin=" + tiempoFin + 
               ", dur=" + duracion + 
               ", amp=" + amplitudMaxima + 
               ", ciclo=" + ciclo + ")";
    }
}
