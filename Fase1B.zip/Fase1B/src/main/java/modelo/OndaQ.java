package modelo;

public class OndaQ extends Onda {
    private static final long serialVersionUID = 1L;
    
    public OndaQ() {}
    
    public OndaQ(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}