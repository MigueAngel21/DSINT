package modelo;

public class IntervaloRR extends Intervalo {
    private static final long serialVersionUID = 1L;
    
    private int cicloInicio;
    private int cicloFin;
    
    public IntervaloRR() {}
    
    public IntervaloRR(int tiempoInicio, int tiempoFin, double amplitudMaxima, 
                       int cicloInicio, int cicloFin) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, cicloInicio);
        this.cicloInicio = cicloInicio;
        this.cicloFin = cicloFin;
    }
    
    public int getCicloInicio() { return cicloInicio; }
    public void setCicloInicio(int cicloInicio) { this.cicloInicio = cicloInicio; }
    
    public int getCicloFin() { return cicloFin; }
    public void setCicloFin(int cicloFin) { this.cicloFin = cicloFin; }
}