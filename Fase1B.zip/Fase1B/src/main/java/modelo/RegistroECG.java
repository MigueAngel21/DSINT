package modelo;

import java.io.Serializable;

public class RegistroECG implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String nombreFichero;
    private int totalCiclos;
    private int frecuenciaCardiaca;
    
    public RegistroECG() {}
    
    public RegistroECG(String nombreFichero) {
        this.nombreFichero = nombreFichero;
        this.totalCiclos = 0;
        this.frecuenciaCardiaca = 0;
    }
    
    public String getNombreFichero() { return nombreFichero; }
    public void setNombreFichero(String nombreFichero) { this.nombreFichero = nombreFichero; }
    
    public int getTotalCiclos() { return totalCiclos; }
    public void setTotalCiclos(int totalCiclos) { this.totalCiclos = totalCiclos; }
    
    public int getFrecuenciaCardiaca() { return frecuenciaCardiaca; }
    public void setFrecuenciaCardiaca(int frecuenciaCardiaca) { 
        this.frecuenciaCardiaca = frecuenciaCardiaca; 
    }
    
    public String toString() {
        return "RegistroECG[" + nombreFichero + 
               ", ciclos=" + totalCiclos + 
               ", FC=" + frecuenciaCardiaca + " ppm]";
    }
}