package modelo;

public class OndaS extends Onda {
    private static final long serialVersionUID = 1L;
    
    public OndaS() {}
    
    public OndaS(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}