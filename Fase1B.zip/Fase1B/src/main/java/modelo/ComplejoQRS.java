package modelo;

/**
 * Clase abstracta que representa un complejo correspondiente a la despolarización ventricular.
 */

public class ComplejoQRS extends ElementoCompuesto {
    private static final long serialVersionUID = 1L;
    
    public ComplejoQRS() {}
    
    public ComplejoQRS(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}