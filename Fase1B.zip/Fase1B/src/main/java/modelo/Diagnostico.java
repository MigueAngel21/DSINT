package modelo;

import java.io.Serializable;

/**
 * Clase abstracta que representa un diagnostico detectado.
 */

public abstract class Diagnostico implements Serializable {
    private static final long serialVersionUID = 1L;
    
    protected String motivoDiagnostico;
    protected int cicloDetectado;
    
    public Diagnostico() {}
    
    public Diagnostico(String motivoDiagnostico, int cicloDetectado) {
        this.motivoDiagnostico = motivoDiagnostico;
        this.cicloDetectado = cicloDetectado;
    }
    
    public String getMotivoDiagnostico() { return motivoDiagnostico; }
    public void setMotivoDiagnostico(String motivoDiagnostico) { 
        this.motivoDiagnostico = motivoDiagnostico; 
    }
    
    public int getCicloDetectado() { return cicloDetectado; }
    public void setCicloDetectado(int cicloDetectado) { 
        this.cicloDetectado = cicloDetectado; 
    }
    
    public String toString() {
        return this.getClass().getSimpleName() + ": " + motivoDiagnostico;
    }
}