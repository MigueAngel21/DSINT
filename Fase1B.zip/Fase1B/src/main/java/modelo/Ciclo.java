package modelo;

import java.io.Serializable;

public class Ciclo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int numeroCiclo;
    
    public Ciclo() {}
    
    public Ciclo(int numeroCiclo) {
        this.numeroCiclo = numeroCiclo;
    }
    
    public int getNumeroCiclo() { return numeroCiclo; }
    public void setNumeroCiclo(int numeroCiclo) { this.numeroCiclo = numeroCiclo; }
    
    public String toString() {
        return "Ciclo(" + numeroCiclo + ")";
    }
}