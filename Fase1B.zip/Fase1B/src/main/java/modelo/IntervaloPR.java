package modelo;

public class IntervaloPR extends Intervalo {
    private static final long serialVersionUID = 1L;
    
    public IntervaloPR() {}
    
    public IntervaloPR(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}