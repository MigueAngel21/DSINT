package modelo;

public class SegmentoTP extends Segmento {
    private static final long serialVersionUID = 1L;
    
    public SegmentoTP() {}
    
    public SegmentoTP(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}