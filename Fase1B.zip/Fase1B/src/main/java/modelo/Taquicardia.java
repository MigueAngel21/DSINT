package modelo;

public class Taquicardia extends Arritmia {
    private static final long serialVersionUID = 1L;
    
    public Taquicardia() {}
    
    public Taquicardia(String motivoDiagnostico, int cicloDetectado) {
        super(motivoDiagnostico, cicloDetectado);
    }
}