package modelo;

public class IntervaloQT extends Intervalo {
    private static final long serialVersionUID = 1L;
    
    public IntervaloQT() {}
    
    public IntervaloQT(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}