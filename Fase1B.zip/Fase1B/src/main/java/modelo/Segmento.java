package modelo;

/**
 * 
 * Clase abstracta que representa un segmento dentro de un ciclo en un ECG.
 *
 */

public abstract class Segmento extends ElementoCompuesto {
    private static final long serialVersionUID = 1L;
    
    public Segmento() {}
    
    public Segmento(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}