package modelo;

public class SegmentoPQ extends Segmento {
    private static final long serialVersionUID = 1L;
    
    public SegmentoPQ() {}
    
    public SegmentoPQ(int tiempoInicio, int tiempoFin, double amplitudMaxima, int ciclo) {
        super(tiempoInicio, tiempoFin, amplitudMaxima, ciclo);
    }
}