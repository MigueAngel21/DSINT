package sistema;

import modelo.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;

/**
 * Parser para leer ficheros .ecg y extraer las ondas básicas
 */
public class ECGParser {
    
    private static final Pattern ONDA_PATTERN = 
        Pattern.compile("([PQRST])\\((\\d+),(\\d+),(-?\\d+\\.?\\d*)\\)");
    
    /**
     * Lee un fichero .ecg y retorna una lista de ondas
     */
    public static List<Onda> parsearFichero(String rutaFichero) throws IOException {
        List<Onda> ondas = new ArrayList<>();
        BufferedReader br = new BufferedReader(
            new InputStreamReader(new FileInputStream(rutaFichero), "UTF-8"));
        
        String linea;
        int numeroCiclo = 0;
        while ((linea = br.readLine()) != null) {
            if (linea.trim().startsWith("#") || linea.trim().isEmpty()) {
                continue;
            }
            
            Matcher matcher = ONDA_PATTERN.matcher(linea);
            while (matcher.find()) {
                String tipo = matcher.group(1);
                int inicio = Integer.parseInt(matcher.group(2));
                int fin = Integer.parseInt(matcher.group(3));
                double amplitud = Double.parseDouble(matcher.group(4));

                if (tipo.equals("P")) {
                    numeroCiclo++;
                }
                
                Onda onda = crearOnda(tipo, inicio, fin, amplitud, numeroCiclo);
                if (onda != null) {
                    ondas.add(onda);
                }
            }
        }
        br.close();
        
        return ondas;
    }
    
    private static Onda crearOnda(String tipo, int inicio, int fin, 
                                   double amplitud, int ciclo) {
        switch (tipo) {
            case "P": return new OndaP(inicio, fin, amplitud, ciclo);
            case "Q": return new OndaQ(inicio, fin, amplitud, ciclo);
            case "R": return new OndaR(inicio, fin, amplitud, ciclo);
            case "S": return new OndaS(inicio, fin, amplitud, ciclo);
            case "T": return new OndaT(inicio, fin, amplitud, ciclo);
            default: return null;
        }
    }
    
    /**
     * Calcula el número total de ciclos en base a las ondas P detectadas
     */
    public static int calcularNumeroCiclos(List<Onda> ondas) {
        int maxCiclo = 0;
        for (Onda o : ondas) {
            if (o.getCiclo() > maxCiclo) {
                maxCiclo = o.getCiclo();
            }
        }
        return maxCiclo;
    }
}